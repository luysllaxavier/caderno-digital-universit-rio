# CRM Líder Conecta

App para **Líderes de Setor Natura e Avon** gerenciarem consultoras e se comunicarem via WhatsApp / chatbot.

## Conteúdo

| Caminho | Descrição |
|---|---|
| `sql/001_schema.sql` | Tipos, tabelas, chaves estrangeiras e triggers |
| `sql/002_indexes.sql` | Índices (telefone, setor, ciclo, fila de disparos) |
| `sql/003_rls.sql` | Políticas RLS e Storage |
| `sql/004_views_dashboard.sql` | Views de métricas do dashboard |
| `docs/01-modelagem-banco.md` | Modelo relacional e diagrama ER |
| `docs/02-api-endpoints.md` | Endpoints REST principais |
| `docs/03-arquitetura-whatsapp.md` | Arquitetura de integração com WhatsApp |
| `docs/04-mensagens-encerramento-ciclo.md` | 3 mensagens de fechamento de ciclo |

## Como aplicar o banco (Supabase)

1. Crie um projeto no Supabase.
2. No **SQL Editor**, execute os arquivos de `sql/` na ordem numérica.
3. Crie o bucket privado `midias` (comando comentado em `003_rls.sql`) antes de rodar as políticas de Storage.
4. Ou, com a Supabase CLI, copie os arquivos para `supabase/migrations/` e rode `supabase db push`.

## Observações

- Os arquivos SQL pressupõem Supabase (`auth.users`, `auth.uid()`, `storage.objects`). Em PostgreSQL puro, adapte a tabela de usuários e as políticas.
- Para produção, prefira a **WhatsApp Cloud API oficial**; veja `docs/03-arquitetura-whatsapp.md`.
