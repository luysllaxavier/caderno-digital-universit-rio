# 02 — Endpoints principais da API (REST)

Base: `/api/v1` · Autenticação: `Authorization: Bearer <JWT do Supabase Auth>`
Escopo: toda operação é restrita à líder autenticada (RLS).

## Autenticação e perfil
| Método | Rota | Descrição |
|---|---|---|
| POST | `/auth/signup` | Cria usuário e perfil de líder |
| POST | `/auth/login` | Login (e-mail/senha ou magic link) |
| GET / PATCH | `/lideres/me` | Ler / atualizar perfil da líder |

## Consultoras
| Método | Rota | Descrição |
|---|---|---|
| GET | `/consultoras?nivel=&status=&setor=&q=&page=` | Lista com filtros e busca por nome/telefone |
| POST | `/consultoras` | Cadastro individual |
| GET / PATCH / DELETE | `/consultoras/{id}` | Detalhe, edição, remoção |
| POST | `/consultoras/importacao` | Upload CSV/Excel (retorna `job_id`) |
| GET | `/consultoras/importacao/{job_id}` | Status e relatório de erros da importação |
| GET | `/consultoras/{id}/conversas` | Histórico de mensagens enviadas/recebidas |
| GET / POST | `/consultoras/{id}/notas` | Notas da consultora |
| GET | `/consultoras/pendentes-contato` | Ativas sem contato recente |

## Ciclos e campanhas
| Método | Rota | Descrição |
|---|---|---|
| GET / POST | `/ciclos` | Listar / criar ciclo (Natura ou Avon) |
| GET / PATCH / DELETE | `/ciclos/{id}` | Detalhe, edição (datas, meta, status) |
| GET / POST | `/ciclos/{id}/midias` | Listar / registrar mídias do ciclo |
| DELETE | `/midias/{id}` | Remover mídia |
| POST | `/midias/upload-url` | URL assinada para upload ao Storage |

## Automações e disparos
| Método | Rota | Descrição |
|---|---|---|
| GET / POST | `/automacoes` | Modelos de mensagem e agendamentos |
| GET / PATCH / DELETE | `/automacoes/{id}` | Detalhe, edição, desativação |
| POST | `/automacoes/{id}/preview` | Renderiza o texto com variáveis para uma consultora |
| POST | `/automacoes/{id}/disparar` | Dispara agora (body: filtros de destinatárias ou lista de IDs) |
| POST | `/automacoes/{id}/agendar` | Define `agendado_para` |
| GET | `/automacoes/{id}/disparos` | Log de disparos da automação |
| POST | `/disparos/{id}/reenviar` | Reenvia um disparo com falha |

## Artes rápidas
| Método | Rota | Descrição |
|---|---|---|
| POST | `/artes/gerar` | Gera imagem a partir de template + textos/cores/logo (retorna URL no Storage) |
| GET | `/artes/templates` | Templates disponíveis |

## Dashboard
| Método | Rota | Descrição |
|---|---|---|
| GET | `/dashboard/resumo?ciclo_id=` | Totais de envios, taxa de entrega e leitura |
| GET | `/dashboard/automacoes` | Métricas por automação (`v_dashboard_disparos`) |
| GET | `/dashboard/pendentes` | Consultoras pendentes de contato |

## Webhooks (uso interno, sem JWT de usuário)
| Método | Rota | Descrição |
|---|---|---|
| GET / POST | `/webhooks/whatsapp` | Verificação e eventos do provedor (status entregue/lido, mensagens recebidas). Valida assinatura HMAC |

## Convenções
- Paginação: `page`, `page_size` (padrão 25).
- Erros: `{ "error": { "code": "...", "message": "..." } }`.
- Disparos em massa são **assíncronos**: a API enfileira e responde `202 Accepted` com um `batch_id`.
- Cabeçalho `Idempotency-Key` em `POST /automacoes/{id}/disparar`.
