# 03 — Arquitetura de integração com WhatsApp

## Recomendação

| Opção | Quando usar | Pontos de atenção |
|---|---|---|
| **WhatsApp Cloud API (oficial, Meta)** | **Recomendada para produção** | Exige conta Business verificada, número dedicado e **templates aprovados** para mensagens iniciadas pela empresa fora da janela de 24h |
| Provedores BSP (Twilio, Gupshup, Take Blip etc.) | Quem quer suporte e faturamento locais | Custo adicional sobre a API oficial |
| Evolution API / Z-API (não oficiais) | Protótipo ou validação rápida | Risco de **bloqueio do número**, violam os termos do WhatsApp; não recomendado para disparos em massa |

Como cada líder tende a usar o próprio número, o desenho acima prevê um **adaptador por provedor**, permitindo começar com um provedor e migrar para a API oficial sem mexer no restante do sistema.

## Visão geral

```mermaid
flowchart LR
  APP[App Mobile/Web da Líder] -->|REST + JWT| API[API / Edge Functions]
  API --> DB[(PostgreSQL Supabase)]
  API --> ST[(Storage de mídias)]
  API -->|enfileira| Q[Fila de envio]
  CRON[Scheduler pg_cron] -->|automações agendadas| Q
  Q --> W[Worker de disparo]
  W -->|Provider Adapter| WA[WhatsApp Cloud API / Evolution / Z-API]
  WA -->|webhooks: status, respostas| HOOK[/webhooks/whatsapp/]
  HOOK --> DB
  W --> DB
```

## Fluxo de um disparo

1. A líder escolhe automação + destinatárias (ou o scheduler encontra automações com `agendado_para <= now()`).
2. A API cria uma linha `pendente` em `log_disparos` por consultora (a restrição única garante idempotência).
3. O worker consome a fila, renderiza as variáveis (`{{nome}}`, `{{ciclo}}`, `{{data_fim}}`) e envia texto ou imagem via adaptador.
4. Atualiza o log para `enviado` e guarda o `provider_message_id`.
5. Webhooks do provedor atualizam para `entregue`, `lido` ou `falha`, alimentando o dashboard.
6. Respostas das consultoras chegam no webhook e entram no histórico de conversas.

## Componentes

- **Interface `WhatsAppProvider`**: `sendText`, `sendImage`, `sendTemplate`, `parseWebhook`. Uma implementação por provedor.
- **Fila**: Supabase Queues (pgmq) ou Redis/BullMQ, com retentativas exponenciais (máx. 3) e limite de taxa por número.
- **Worker**: Edge Function ou serviço Node.js separado, usando `service_role` (ignora RLS) e sempre filtrando por `lider_id`.
- **Segredos**: tokens do provedor criptografados (Supabase Vault); nunca expostos ao app.
- **Webhook**: valida assinatura (`X-Hub-Signature-256` na API oficial) e responde rápido, processando de forma assíncrona.

## Boas práticas e conformidade

- **Opt-in**: registre o consentimento da consultora e ofereça opt-out ("responda SAIR"). Respeita a LGPD e reduz denúncias de spam.
- **Templates**: mensagens de lembrete/cobrança fora da janela de 24h devem usar templates aprovados (categoria *utility* ou *marketing*).
- **Ritmo de envio**: espaçar disparos e variar texto para evitar bloqueio.
- **Mídias**: envie URLs assinadas e de curta duração; imagens JPEG/PNG até 5 MB.
- **Artes dinâmicas**: gerar no servidor (Satori/Sharp ou Canvas) a partir de templates, salvar no Storage e reutilizar a URL no disparo.
- **Observabilidade**: logs estruturados, alerta quando a taxa de falha ultrapassar um limite.

## Variáveis de ambiente (exemplo)

```
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
WHATSAPP_PROVIDER=cloud_api   # cloud_api | evolution | zapi
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_WEBHOOK_VERIFY_TOKEN=
WHATSAPP_APP_SECRET=
```
