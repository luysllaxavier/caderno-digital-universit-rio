# 04 — Mensagens de encerramento de ciclo

Substitua os campos entre colchetes: `[Marca]` (Natura ou Avon), `[Número]` do ciclo, `[Nome]`, `[data/hora]` e `[Seu nome]`.
Variáveis para o app: `{{nome}}`, `{{ciclo}}`, `{{data_fim}}`.

## Opção 1 — Acolhedora e motivadora

> Oi, [Nome]! 💛 Passando para lembrar que o Ciclo [Número] da [Marca] fecha em [data/hora]. Ainda dá tempo de enviar seus pedidos e garantir seus ganhos. Conta comigo para o que precisar. Vamos juntas! 🚀

## Opção 2 — Persuasiva com senso de oportunidade

> [Nome], faltam poucas horas para o fechamento do Ciclo [Número] da [Marca]! ⏰ Quem fecha agora aproveita as ofertas e ainda se aproxima do próximo nível. Posso te ajudar a finalizar seu pedido hoje? 😉

## Opção 3 — Leve, com reconhecimento

> Oi, [Nome]! 🌸 Você tem feito um trabalho lindo neste ciclo. Só um lembrete: o Ciclo [Número] da [Marca] encerra em [data/hora]. Se faltar algum pedido, me chama que resolvemos juntas. Obrigada por fazer parte da minha equipe! 💜

## Versão com variáveis (para cadastrar em `automacoes_mensagens`)

```
Oi, {{nome}}! 💛 O Ciclo {{ciclo}} fecha em {{data_fim}}. Ainda dá tempo de enviar seus pedidos. Conta comigo! 🚀
```

**Dica:** alterne as três versões entre as consultoras para reduzir repetição e risco de bloqueio, e use a imagem do banner do ciclo (`midias_campanha`) como anexo.
