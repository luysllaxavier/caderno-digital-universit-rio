# 01 — Modelagem Relacional (PostgreSQL / Supabase)

## Diagrama ER

```mermaid
erDiagram
  AUTH_USERS ||--|| LIDERES : "user_id"
  LIDERES ||--o{ CONSULTORAS : "lider_id"
  LIDERES ||--o{ CAMPANHAS_CICLOS : "lider_id"
  LIDERES ||--o{ AUTOMACOES_MENSAGENS : "lider_id"
  CAMPANHAS_CICLOS ||--o{ MIDIAS_CAMPANHA : "campanha_id"
  CAMPANHAS_CICLOS ||--o{ AUTOMACOES_MENSAGENS : "campanha_id (opcional)"
  AUTOMACOES_MENSAGENS ||--o{ LOG_DISPAROS : "automacao_id"
  CONSULTORAS ||--o{ LOG_DISPAROS : "consultora_id"
```

## Tabelas

| Tabela | Chave primária | Chaves estrangeiras | Restrições principais |
|---|---|---|---|
| `lideres` | `id` (uuid) | `user_id → auth.users` | `user_id` e `email` únicos |
| `consultoras` | `id` | `lider_id → lideres` | telefone E.164; único `(lider_id, telefone_whatsapp)` |
| `campanhas_ciclos` | `id` | `lider_id → lideres` | `data_fim >= data_inicio`; único `(lider_id, marca, numero_ciclo)` |
| `midias_campanha` | `id` | `campanha_id → campanhas_ciclos` | arquivos no Supabase Storage |
| `automacoes_mensagens` | `id` | `lider_id → lideres`, `campanha_id → campanhas_ciclos` (opcional) | variáveis `{{nome}}`, `{{ciclo}}`, `{{data_fim}}` |
| `log_disparos` | `id` | `automacao_id`, `consultora_id` | único `(automacao_id, consultora_id)` evita envio duplicado |

## Tabelas de apoio sugeridas (fase 2)

Para o requisito de **histórico de conversas e notas**, recomenda-se adicionar:

- `mensagens_recebidas` (`id`, `consultora_id`, `conteudo`, `recebida_em`, `provider_message_id`) para respostas via webhook;
- `notas_consultora` (`id`, `consultora_id`, `lider_id`, `texto`, `created_at`);
- `tags` / `consultora_tags` para categorizações livres (Destaque, Em risco etc.);
- `consentimentos_whatsapp` (`consultora_id`, `opt_in_em`, `opt_out_em`) para LGPD e regras do WhatsApp.

## Decisões de projeto

- **Multi-tenant por líder** com RLS: cada linha pertence a uma `lider_id` direta ou indiretamente.
- **Enums nativos** para nível, status, marca e gatilho (valores controlados e indexáveis).
- **Status `entregue` e `lido`** adicionados a `status_envio` para alimentar a taxa de entrega/leitura do dashboard.
- **Telefone em E.164** (`+55...`) para casar com os webhooks do WhatsApp.
- **Idempotência**: a restrição única em `log_disparos` impede disparar duas vezes a mesma automação para a mesma consultora.

## Ordem de execução

1. `sql/001_schema.sql`
2. `sql/002_indexes.sql`
3. `sql/003_rls.sql`
4. `sql/004_views_dashboard.sql`
