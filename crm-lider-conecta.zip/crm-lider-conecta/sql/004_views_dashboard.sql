-- =====================================================================
-- 004_views_dashboard.sql — métricas do painel (respeitam RLS)
-- =====================================================================

-- Resumo por automação: totais, taxa de entrega e leitura
create or replace view public.v_dashboard_disparos
with (security_invoker = true) as
select
  a.id                                                                    as automacao_id,
  a.lider_id,
  a.titulo_modelo,
  a.gatilho,
  count(l.id)                                                             as total,
  count(*) filter (where l.status_envio in ('enviado','entregue','lido')) as enviados,
  count(*) filter (where l.status_envio in ('entregue','lido'))           as entregues,
  count(*) filter (where l.status_envio = 'lido')                         as lidos,
  count(*) filter (where l.status_envio = 'falha')                        as falhas,
  count(*) filter (where l.status_envio = 'pendente')                     as pendentes,
  round(100.0 * count(*) filter (where l.status_envio in ('entregue','lido'))
        / nullif(count(l.id), 0), 1)                                      as taxa_entrega_pct,
  round(100.0 * count(*) filter (where l.status_envio = 'lido')
        / nullif(count(l.id), 0), 1)                                      as taxa_leitura_pct
from public.automacoes_mensagens a
left join public.log_disparos l on l.automacao_id = a.id
group by a.id;

-- Consultoras ativas sem contato nos últimos 15 dias
create or replace view public.v_consultoras_pendentes_contato
with (security_invoker = true) as
select c.id, c.lider_id, c.nome, c.telefone_whatsapp, c.setor, c.nivel,
       max(l.data_envio) as ultimo_contato
from public.consultoras c
left join public.log_disparos l
       on l.consultora_id = c.id and l.status_envio in ('enviado','entregue','lido')
where c.status = 'Ativa'
group by c.id
having max(l.data_envio) is null or max(l.data_envio) < now() - interval '15 days';
