-- =====================================================================
-- CRM Líder Conecta — Schema PostgreSQL (Supabase)
-- 001_schema.sql: extensões, tipos, tabelas, FKs, triggers
-- =====================================================================

create extension if not exists pgcrypto;   -- gen_random_uuid()

-- ---------------------------------------------------------------------
-- Tipos enumerados
-- ---------------------------------------------------------------------
create type marca_lider        as enum ('Natura', 'Avon', 'Ambas');
create type marca_campanha     as enum ('Natura', 'Avon');
create type nivel_consultora   as enum ('Semente', 'Bronze', 'Prata', 'Ouro', 'Diamante');
create type status_consultora  as enum ('Ativa', 'Inativa');
create type status_ciclo       as enum ('planejado', 'aberto', 'encerrado');
create type tipo_midia         as enum ('imagem', 'pdf', 'banner');
create type gatilho_automacao  as enum (
  'Boas-vindas', 'Lembrete Fechamento', 'Parabéns Conquista', 'Cobrança Amigável', 'Personalizado'
);
-- 'entregue' e 'lido' são alimentados pelos webhooks do provedor (dashboard)
create type status_envio       as enum ('pendente', 'enviado', 'entregue', 'lido', 'falha');

-- ---------------------------------------------------------------------
-- Função utilitária: updated_at
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------------------------------------------------------------------
-- 1. lideres
-- ---------------------------------------------------------------------
create table public.lideres (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null unique references auth.users (id) on delete cascade,
  nome            text not null,
  marca_principal marca_lider not null default 'Natura',
  telefone        text,
  email           text not null unique,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 2. consultoras
-- ---------------------------------------------------------------------
create table public.consultoras (
  id                uuid primary key default gen_random_uuid(),
  lider_id          uuid not null references public.lideres (id) on delete cascade,
  nome              text not null,
  telefone_whatsapp text not null,                 -- formato E.164, ex.: +5599999999999
  nivel             nivel_consultora  not null default 'Semente',
  setor             text,
  status            status_consultora not null default 'Ativa',
  observacoes       text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  constraint consultoras_telefone_e164 check (telefone_whatsapp ~ '^\+[1-9][0-9]{7,14}$'),
  constraint consultoras_telefone_unico_por_lider unique (lider_id, telefone_whatsapp)
);

-- ---------------------------------------------------------------------
-- 3. campanhas_ciclos
-- ---------------------------------------------------------------------
create table public.campanhas_ciclos (
  id            uuid primary key default gen_random_uuid(),
  lider_id      uuid not null references public.lideres (id) on delete cascade,
  marca         marca_campanha not null,
  numero_ciclo  integer not null check (numero_ciclo > 0),
  data_inicio   date not null,
  data_fim      date not null,
  meta_vendas   numeric(12,2) check (meta_vendas >= 0),
  status        status_ciclo not null default 'planejado',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint ciclos_datas_validas check (data_fim >= data_inicio),
  constraint ciclos_unico_por_lider unique (lider_id, marca, numero_ciclo)
);

-- ---------------------------------------------------------------------
-- 4. midias_campanha
-- ---------------------------------------------------------------------
create table public.midias_campanha (
  id           uuid primary key default gen_random_uuid(),
  campanha_id  uuid not null references public.campanhas_ciclos (id) on delete cascade,
  titulo       text not null,
  tipo         tipo_midia not null,
  url_storage  text not null,                      -- caminho no Supabase Storage
  created_at   timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 5. automacoes_mensagens
-- ---------------------------------------------------------------------
create table public.automacoes_mensagens (
  id             uuid primary key default gen_random_uuid(),
  lider_id       uuid not null references public.lideres (id) on delete cascade,
  campanha_id    uuid references public.campanhas_ciclos (id) on delete set null,
  titulo_modelo  text not null,
  texto_mensagem text not null,                    -- variáveis: {{nome}}, {{ciclo}}, {{data_fim}}
  gatilho        gatilho_automacao not null,
  imagem_url     text,
  agendado_para  timestamptz,
  ativo          boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 6. log_disparos
-- ---------------------------------------------------------------------
create table public.log_disparos (
  id                  uuid primary key default gen_random_uuid(),
  automacao_id        uuid not null references public.automacoes_mensagens (id) on delete cascade,
  consultora_id       uuid not null references public.consultoras (id) on delete cascade,
  status_envio        status_envio not null default 'pendente',
  data_envio          timestamptz,
  provider_message_id text,                        -- id da mensagem no WhatsApp/provedor
  erro                text,
  created_at          timestamptz not null default now(),
  constraint disparo_unico_por_consultora unique (automacao_id, consultora_id)
);

-- ---------------------------------------------------------------------
-- Triggers de updated_at
-- ---------------------------------------------------------------------
create trigger trg_lideres_updated     before update on public.lideres
  for each row execute function public.set_updated_at();
create trigger trg_consultoras_updated before update on public.consultoras
  for each row execute function public.set_updated_at();
create trigger trg_ciclos_updated      before update on public.campanhas_ciclos
  for each row execute function public.set_updated_at();
create trigger trg_automacoes_updated  before update on public.automacoes_mensagens
  for each row execute function public.set_updated_at();
