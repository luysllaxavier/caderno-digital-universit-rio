-- =====================================================================
-- 003_rls.sql — Row Level Security (multi-tenant por líder)
-- Cada líder só enxerga e altera os próprios dados.
-- O backend/worker de disparos usa a service_role (ignora RLS).
-- =====================================================================

-- Retorna o id da líder logada (SECURITY DEFINER evita recursão de RLS)
create or replace function public.current_lider_id()
returns uuid
language sql stable security definer
set search_path = public
as $$
  select id from public.lideres where user_id = auth.uid()
$$;

alter table public.lideres              enable row level security;
alter table public.consultoras          enable row level security;
alter table public.campanhas_ciclos     enable row level security;
alter table public.midias_campanha      enable row level security;
alter table public.automacoes_mensagens enable row level security;
alter table public.log_disparos         enable row level security;

-- ---------------- lideres ----------------
create policy lideres_select on public.lideres
  for select to authenticated using (user_id = auth.uid());
create policy lideres_insert on public.lideres
  for insert to authenticated with check (user_id = auth.uid());
create policy lideres_update on public.lideres
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------- consultoras ----------------
create policy consultoras_all on public.consultoras
  for all to authenticated
  using (lider_id = public.current_lider_id())
  with check (lider_id = public.current_lider_id());

-- ---------------- campanhas_ciclos ----------------
create policy ciclos_all on public.campanhas_ciclos
  for all to authenticated
  using (lider_id = public.current_lider_id())
  with check (lider_id = public.current_lider_id());

-- ---------------- midias_campanha (via campanha) ----------------
create policy midias_all on public.midias_campanha
  for all to authenticated
  using (exists (
    select 1 from public.campanhas_ciclos c
    where c.id = midias_campanha.campanha_id and c.lider_id = public.current_lider_id()))
  with check (exists (
    select 1 from public.campanhas_ciclos c
    where c.id = midias_campanha.campanha_id and c.lider_id = public.current_lider_id()));

-- ---------------- automacoes_mensagens ----------------
create policy automacoes_all on public.automacoes_mensagens
  for all to authenticated
  using (lider_id = public.current_lider_id())
  with check (
    lider_id = public.current_lider_id()
    and (campanha_id is null or exists (
      select 1 from public.campanhas_ciclos c
      where c.id = campanha_id and c.lider_id = public.current_lider_id()))
  );

-- ---------------- log_disparos ----------------
-- Líder pode LER e CRIAR logs apenas de suas automações e consultoras.
-- Atualizações de status (webhooks) são feitas pela service_role.
create policy log_select on public.log_disparos
  for select to authenticated
  using (exists (
    select 1 from public.automacoes_mensagens a
    where a.id = log_disparos.automacao_id and a.lider_id = public.current_lider_id()));

create policy log_insert on public.log_disparos
  for insert to authenticated
  with check (
    exists (select 1 from public.automacoes_mensagens a
            where a.id = automacao_id and a.lider_id = public.current_lider_id())
    and exists (select 1 from public.consultoras k
            where k.id = consultora_id and k.lider_id = public.current_lider_id())
  );

-- ---------------- Storage (bucket de mídias) ----------------
-- Crie o bucket antes (privado):
--   insert into storage.buckets (id, name, public) values ('midias', 'midias', false);
-- Estrutura de caminho: <lider_id>/<arquivo>
create policy midias_storage_rw on storage.objects
  for all to authenticated
  using (bucket_id = 'midias' and (storage.foldername(name))[1] = public.current_lider_id()::text)
  with check (bucket_id = 'midias' and (storage.foldername(name))[1] = public.current_lider_id()::text);
