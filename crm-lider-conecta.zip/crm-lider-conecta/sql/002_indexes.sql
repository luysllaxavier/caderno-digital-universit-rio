-- =====================================================================
-- 002_indexes.sql — índices para busca rápida
-- =====================================================================

-- Telefone (webhook recebe o número e precisa achar a consultora)
create index idx_consultoras_telefone     on public.consultoras (telefone_whatsapp);
-- Setor / status dentro da carteira da líder
create index idx_consultoras_lider_setor  on public.consultoras (lider_id, setor);
create index idx_consultoras_lider_status on public.consultoras (lider_id, status, nivel);

-- Ciclos (o UNIQUE já cobre lider+marca+ciclo)
create index idx_ciclos_numero            on public.campanhas_ciclos (marca, numero_ciclo);
create index idx_ciclos_lider_status      on public.campanhas_ciclos (lider_id, status, data_fim);

-- Mídias por campanha
create index idx_midias_campanha          on public.midias_campanha (campanha_id);

-- Automações: o scheduler busca o que está agendado e ativo
create index idx_automacoes_lider         on public.automacoes_mensagens (lider_id);
create index idx_automacoes_agendadas     on public.automacoes_mensagens (agendado_para)
  where ativo = true and agendado_para is not null;

-- Log de disparos: dashboard e fila
create index idx_log_automacao_status     on public.log_disparos (automacao_id, status_envio);
create index idx_log_consultora           on public.log_disparos (consultora_id, data_envio desc);
create index idx_log_pendentes            on public.log_disparos (created_at) where status_envio = 'pendente';
create index idx_log_provider_msg         on public.log_disparos (provider_message_id)
  where provider_message_id is not null;
